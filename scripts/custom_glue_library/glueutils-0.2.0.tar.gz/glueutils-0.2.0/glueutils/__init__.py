"""
glueutils.

An  python library that writes glue dynamic frame and updates partition.
"""

__version__ = "0.2.0"
__author__ = 'AWS'

