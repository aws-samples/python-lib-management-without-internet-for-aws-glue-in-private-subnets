import datetime
import sys

from awsglue import DynamicFrame
from awsglue.context import GlueContext
from pyspark.context import SparkContext
from pyspark.sql import DataFrame, Row


def write_to_s3(glue_context: GlueContext,
                dyn_frame: DynamicFrame, 
                s3_tgt_path: str, 
                glue_tbl_tgt: str, 
                glue_db_tgt: str,
                partition_cols: list, 
                outputformat: str = 'glueparquet'):
    """This function creates a S3 data sink, configures the sink with the
    values provided in the arguments, writes the dynamic frame to it, and
    updates the Glue Data Catalog

    Args:
        glue_context (GlueContext): Glue Context for the application
        dyn_frame (DynamicFrame): input dynamic frame used for writing data
        s3_tgt_path (str): path to the S3 bucket
        glue_tbl_tgt (str): name of the target S3 table
        glue_db_tgt (str): name of the target S3 database
        partition_cols (list): list of names of the partition columns
        outputformat (str, optional): desired format of the data. 
            Defaults to 'glueparquet'.
    """
    
    DataSinkforS3 = glue_context.getSink(
        path=s3_tgt_path+glue_tbl_tgt,
        connection_type="s3",
        updateBehavior="UPDATE_IN_DATABASE",
        partitionKeys=partition_cols,
        enableUpdateCatalog=True,
        transformation_ctx="DataSink0")
    DataSinkforS3.setCatalogInfo(catalogDatabase=glue_db_tgt, catalogTableName=glue_tbl_tgt)
    DataSinkforS3.setFormat(outputformat)
    DataSinkforS3.writeFrame(dyn_frame)
