from setuptools import setup

setup(
    name='glueutils',
    version='0.2.0',    
    description='Sample Glue Writer Package',
    license='MIT',
    author='AWS',
    packages=['glueutils'],
    install_requires=[ 'boto3',                     
                      ],

    classifiers=[
        'Development Status :: 1 - Planning',
        'Operating System :: POSIX :: Linux',        
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.4',
        'Programming Language :: Python :: 3.5',
		'Programming Language :: Python :: 3.6',
    ],
)

